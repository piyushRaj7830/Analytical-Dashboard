# HR-Analytical-Dashboard-
Designing an Analytic Human Resource Dashboard using Tableau and Database Management 
